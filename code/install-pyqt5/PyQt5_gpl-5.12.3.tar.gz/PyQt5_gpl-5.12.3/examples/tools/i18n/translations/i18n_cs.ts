<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>View</source>
        <translation>Pohled</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Soubor</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Konec</translation>
    </message>
    <message>
        <source>First</source>
        <translation>První</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Třetí</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Jayzk: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Český</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Nakloněný</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Druhý</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isometrický</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspektivní</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Ukázka lokalizace</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
